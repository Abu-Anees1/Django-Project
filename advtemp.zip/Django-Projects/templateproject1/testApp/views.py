from django.shortcuts import render
import datetime

# Create your views here.
def fun1(request):
	date=datetime.datetime.now()
	d={'date_msg':date}
	return render(request,'testApp/wish.html',context=d)