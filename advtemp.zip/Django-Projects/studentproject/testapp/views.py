from django.shortcuts import render
from  testapp import forms
# Create your views here.


def fun1(request):
	form=forms.StudentForm()
	if request.method=='POST':
		form=forms.StudentForm(request.POST)
		if form.is_valid():
			form.save()
			print('form data inserted into succsessfully')
	return render(request,'testapp/stu.html',{'form':form})
