from django.shortcuts import render
from testapp.forms import NameForm,AgeForm,GfForm
# Create your views here.


def fun1(request):
	form=NameForm()
	return render(request,'testapp/name.html',{'form':form})

def fun2(request):
	name=request.GET['name']
	request.session['name']=name
	form=AgeForm()
	return render(request,'testapp/age.html',{'from':form})

def fun3(request):
	age=request.GET['age']
	request.session['age']=age
	form=GfForm()
	return render(request,'testapp/gf.html',{'from':form})


def fun4(request):
	gf=request.GET['gf']
	request.session['gf']=gf
	form=GfForm()
	return render(request,'testapp/result.html')
