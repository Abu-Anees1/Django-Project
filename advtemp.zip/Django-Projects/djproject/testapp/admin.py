from django.contrib import admin
from testapp.models import hyd,bng,chn,pune
# Register your models here.
class hydAdmin(admin.ModelAdmin):
	list_display=['date','company','title','eligibility','address','email','phonenumber']


class bngAdmin(admin.ModelAdmin):
	list_display=['date','company','title','eligibility','address','email','phonenumber']


class chnAdmin(admin.ModelAdmin):
	list_display=['date','company','title','eligibility','address','email','phonenumber']



class puneAdmin(admin.ModelAdmin):
	list_display=['date','company','title','eligibility','address','email','phonenumber']


admin.site.register(hyd,hydAdmin)
admin.site.register(bng,bngAdmin)
admin.site.register(chn,chnAdmin)
admin.site.register(pune,puneAdmin)