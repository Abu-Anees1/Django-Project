from django.shortcuts import render
from testapp.models import *
# Create your views here.
def hyd1(request):
	jobs_list=hyd.objects.all()
	my_dict={'jobs_list':jobs_list}
	return render(request,'testapp/hydjobs.html',context=my_dict)