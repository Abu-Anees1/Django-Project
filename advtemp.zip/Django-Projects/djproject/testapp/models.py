from django.db import models

# Create your models here.
class hyd(models.Model):
	date=models.DateField()
	company=models.CharField(max_length=100)
	title=models.CharField(max_length=100)
	eligibility=models.CharField(max_length=100)
	address=models.CharField(max_length=100)
	email=models.CharField(max_length=100)
	phonenumber=models.IntegerField()
	def __str__(self):
		return self.company



class bng(models.Model):
	date=models.DateField()
	company=models.CharField(max_length=100)
	title=models.CharField(max_length=100)
	eligibility=models.CharField(max_length=100)
	address=models.CharField(max_length=100)
	email=models.CharField(max_length=100)
	phonenumber=models.IntegerField()


class chn(models.Model):
	date=models.DateField()
	company=models.CharField(max_length=100)
	title=models.CharField(max_length=100)
	eligibility=models.CharField(max_length=100)
	address=models.CharField(max_length=100)
	email=models.CharField(max_length=100)
	phonenumber=models.IntegerField()



class pune(models.Model):
	date=models.DateField()
	company=models.CharField(max_length=100)
	title=models.CharField(max_length=100)
	eligibility=models.CharField(max_length=100)
	address=models.CharField(max_length=100)
	email=models.CharField(max_length=100)
	phonenumber=models.IntegerField()


