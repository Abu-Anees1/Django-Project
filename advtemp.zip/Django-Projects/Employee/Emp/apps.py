from django.apps import AppConfig


class EmpConfig(AppConfig):
    name = 'Emp'
