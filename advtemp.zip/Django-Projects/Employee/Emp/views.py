from django.shortcuts import render
from Emp.models import Employee
from django.http import HttpResponse

# Create your views here.
def fun2(request):
	return render(request,'Empapp/emp2.html')






def fun1(request):
	Emp_list=Employee.objects.all()
	my_dict={'Emp_list':Emp_list}
	return render(request,'Empapp/emp.html',context=my_dict)


