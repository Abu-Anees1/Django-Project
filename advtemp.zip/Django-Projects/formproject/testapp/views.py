from django.shortcuts import render
from . import forms
# Create your views here.
def fun1(request):
	form=forms.StudentRegistration()
	return render(request,'testapp/f.html',{'form':form})