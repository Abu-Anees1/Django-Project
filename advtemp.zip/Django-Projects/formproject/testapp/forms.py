from django import forms
class StudentRegistration(forms.Form):
	name=forms.CharField(max_length=30)
	marks=forms.IntegerField()