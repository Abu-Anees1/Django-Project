from django.shortcuts import render
import datetime
# Create your views here.
def fun1(request):
	date=datetime.datetime.now()
	name='abu'
	h=int(date.strftime('%H'))
	if h<12:
		msg='Good morning'
	elif h<16:
		msg="good afternoon"
	elif h<22:
		msg="good evening"
	else:
		msg="good night"
	my_dict={'msg1':date,'guest':name,'msg':msg}
	return render(request,'testApp/abu.html',context=my_dict)
