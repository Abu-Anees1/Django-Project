from django.contrib import admin
from django.urls import path,include
from testApp import views
urlpatterns = [
    path('path1/',views.fun1)
]