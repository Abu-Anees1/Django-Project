from django.shortcuts import render
from testapp.models import FilterModel
# Create your views here.
def fun1(request):
	data_list=FilterModel.objects.all()
	return render(request,'testapp/upper.html',{'data_list':data_list})