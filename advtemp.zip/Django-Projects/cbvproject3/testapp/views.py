from django.shortcuts import render
from testapp.models import Company
from django.views.generic import ListView,DetailView,CreateView,UpdateView,DeleteView
from django.urls import reverse_lazy
# Create your views here.
class CompanyListView(ListView):
	model=Company
	#Comapny_list.html
class Companydetailview(DetailView):
	model=Company



class Companycreateview(CreateView):
	model=Company
	fields=('name','location','ceo')

class Companyupdateview(UpdateView):
	model=Company
	fields=('name','ceo')


class Companydeleteview(DeleteView):
	model=Company
	success_url=reverse_lazy('companies')
