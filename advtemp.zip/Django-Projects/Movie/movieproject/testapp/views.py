from django.shortcuts import render
from testapp.forms import MovieForms
from testapp.models import Movie

# Create your views here.
def fun1(request):
	return render(request,'testapp/m1.html')


def fun2(request):
	form=MovieForms()
	if request.method=='POST':
		form=MovieForms(request.POST)
		if form.is_valid():
			form.save()
		return fun1(request)
	return render(request,'testapp/m2.html',{'form':form})

def fun3(render):
	Movie_list=Movie.objects.all()
	return render(request,'testapp/m3.html',{'Movie_list':Movie_list})