from django.shortcuts import render
from django.views.generic import ListView,DetailView
from testapp.models import Book
# Create your views here.
class Booklistview(ListView):
	model=Book
	#template_name='testapp/books.html'
	# default template book _list.html
	#default context_object:book_list  

class Bookdetailview(DetailView):
	model=Book
	#dfault template name:book_detail.html
	#dafault context :book or object