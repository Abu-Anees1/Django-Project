from django.shortcuts import render
from testapp.forms import AddForm
# Create your views here.

def additems(request):
	form=AddForm()
	if request.method=="POST":
		name=request.POST['name']
		quality=request.POST['quality']
		request.session[name]=quality
	return render(request,'testapp/add.html',{'form':form})


def fun2(request):
	return render(request,'testapp/display.html')
