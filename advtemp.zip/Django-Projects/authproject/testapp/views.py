from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from testapp.forms import signup
from django.http import HttpResponseRedirect

def fun1(request):
	return render(request,'testapp/home.html')

@login_required
def java(request):
	return render(request,'testapp/java.html')

@login_required
def python(request):
	return render(request,'testapp/python.html')

@login_required
def aptitude(request):
	return render(request,'testapp/aptitude.html')

def login(request):
	return render(request,'testapp/logout.html')


def sign(request):
	form=signup()
	if request.method=='POST':
		form=signup(request.POST)
		#if form.is_valid():
		#	form.save()
		user=form.save()
		user.set_password(user.password)
		user.save()
		return HttpResponseRedirect('/accounts/login')
	return render(request,'testapp/signup.html',{'form':form})

