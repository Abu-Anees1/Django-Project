from django.shortcuts import render
from . import forms
# Create your views here.
def fun2(request):
	return render(request,'testapp/feed2.html')



def fun1(request):
	form=forms.FeedbackForm()
	if request.method=='POST':
		form=forms.FeedbackForm(request.POST)
		if form.is_valid():
			print('for validation is succsess and printing feedback info')
			print('student Name:',form.cleaned_data['name'])
			print('student Rollno:',form.cleaned_data['rollno'])
			print('student Email:',form.cleaned_data['email'])
			print('student Feedback:',form.cleaned_data['Feedback'])
			return fun2(request)

	return render(request,'testapp/feed1.html',{'form':form})

