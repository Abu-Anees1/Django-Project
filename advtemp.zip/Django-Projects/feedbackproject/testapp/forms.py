from django import forms
from django.core import validators

def starts_with_d(value):
	if value[0]!='d':
		raise forms.ValidationError("name should be starts with d")

def gmail_verification(value):
	if value[len(value)-9:] !='gmail.com':
		raise forms.ValidationError('must be gmail')


class FeedbackForm(forms.Form):
	name=forms.CharField(validators=[starts_with_d])
	rollno=forms.IntegerField()
	email=forms.EmailField(validators=[gmail_verification])
	Feedback=forms.CharField(widget=forms.Textarea,validators=[validators.MaxLengthValidator(40)])
	
















