from django.shortcuts import render
from django.db.models import Q
from testapp.models import Employee
from testapp.forms import EmployeeForm
# Create your views here.
def  fun1(request):
	
	employees=Employee.objects.get_emp_sal_range(12000,17000)

	print(type(employees))
	my_dict={'employees':employees}
	return render(request,'testapp/index.html',my_dict)