from django.apps import AppConfig


class TestappConfig(AppConfig):
    name = 'testapp'
