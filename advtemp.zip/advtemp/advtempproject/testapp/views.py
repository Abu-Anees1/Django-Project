from django.shortcuts import render

# Create your views here.
def fun1(request):
	return render(request,'testapp/home.html')


def fun2(request):
	return render(request,'testapp/movie.html')


def fun3(request):
	return render(request,'testapp/politic.html')


def fun4(request):
	return render(request,'testapp/sports.html')

