from django.contrib import admin
from blog.models import post
# Register your models here.
class postAdmin(admin.ModelAdmin):
	list_display=['title','slug','author','body','publish','created','updeted','status']
	prepopulated_fields={'slug':('title',)}
	list_filter=('status','author','publish')
	search_fields=('title','body')
	raw_id_fields=('author',)
	date_hierarchy='publish'
	ordering=['status','publish']
admin.site.register(post,postAdmin)